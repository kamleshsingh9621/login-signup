-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 03, 2023 at 11:31 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `registration`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `user`
-- 

CREATE TABLE `user` (
  `id` int(255) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`id`, `name`, `username`, `email`, `phone`, `city`, `address`, `qualification`, `password`) VALUES 
(1, 'kamlesh singh', 'kamlesh123', 'kamlesh123@gmail.com', '9554422548', 'Kushinagar', 'Adrauna, Parsauni Kushinagar', '12th & above', '123456'),
(2, 'Ashish Kumar', 'ashish123', 'ashish123@gmail.com', '9554422548', 'Gajipur', 'Mohanlal ganj', '12th & above', '1234'),
(3, 'Subhash Pal', 'subhash123', 'subhash123@gmail.com', '9554422548', 'Sultanpur', 'Amethi Sultanpur', '12th & above', '1234');
