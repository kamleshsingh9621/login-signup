<?php
session_start();
mysql_connect("localhost","root","");
mysql_select_db(registration);
if(isset($_POST['submit'])){
  $name = $_POST['name'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $city = $_POST['city'];
  $address = $_POST['address'];
  $qualification = $_POST['qualification'];
  $password = $_POST['password'];
  $result = "insert into user (name, username, email, phone, city, address, qualification, password)values('$name', '$username', '$email', '$phone', '$city','$address', '$qualification', '$password')";
  if(mysql_query($result)){
    echo "<script> alert('data inserted successfully');</script>";
    header("location:login.php");
  }
  else{
    echo "<script> alert('data not inserted');</script>";
  }

}
?>
<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="register.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form action="" method="post" autocomplete="off">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Full Name</span>
            <input type="text" name="name" placeholder="Enter your name *"  autocomplete="off">
          </div>

          <div class="input-box">
            <span class="details">Username</span>
            <input type="text" name="username" placeholder="Enter your @username *"  autocomplete="off">
          </div>
         
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" name="email" placeholder="Enter your email *">
          </div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" name="phone" placeholder="Enter your number *" >
          </div>
          <div class="input-box">
            <span class="details">City</span>
            <select name="city" class="option">
              <option hidden="">Select City</option>
              <option value="Agra">Agra</option>
              <option value="Allahabad">Allahabad</option>
              <option value="Banaras">Banaras</option>
              <option value="Gajipur">Gajipur</option>
              <option value="Gorakhpur">Gorakhpur</option>
              <option value="Kanpur">Kanpur</option>
              <option value="Kushinagar">Kushinagar</option>
              <option value="Lucknow">Lucknow</option>
              <option value="Mau">Mau</option>
              <option value="New Delhi">New Delhi</option>
              <option value="Raibareli">Raibareli</option>
              <option value="Sultanpur">Sultanpur</option>
            </select>
          </div>

          <div class="input-box">
            <span class="details">Address</span>
            <input type="text" name="address" placeholder="Enter your address *"  autocomplete="off">
          </div>

          <div class="input-box">
            <span class="details">Qualification</span>
            <select name="qualification"  class="option">
              <option hidden="">Qualification</option>
              <option value="Below 10th">Below 10th</option>
              <option value="10th">10th</option>
              <option value="10th & above">10th & above</option>
              <option value="12th">12th</option>
              <option value="12th & above">12th & above</option>
              <option value="Graduated">Graduated</option>
            </select>
          </div>


          <div class="input-box">
            <span class="details">Password</span>
            <input type="text" name="password" placeholder="Enter your password *" >
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="text" name="cpassword" placeholder="Confirm your password *" >
          </div>
        </div>

        <div class="button">
          <input type="submit" name="submit" value="Register">
        </div>
          
      </form>
      <div style=" margin-left: 200px;">Already have an account : -
      <a href="login.php">Login</a></div>
      
    </div>
  </div>

</body>
</html>
