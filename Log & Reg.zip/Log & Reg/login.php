<?php
mysql_connect("localhost","root","");
mysql_select_db(registration);
if(isset($_POST['submit']))
{
  $username=$_POST['username'];
  $password=$_POST['password'];
  $result=mysql_query("select username from user where username='$username' and password='$password'");
  $count=mysql_num_rows($result);
  if($count>0)
  {
    session_start();
    $_SESSION["username"]=$username;
    header("location:portfolio.php");

  }
  else
  {
    echo "no matched";
  }
}
?>
<!DOCTYPE html>
<!-- Created By CodingLab - www.codinglabweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!---<title> Responsive Registration Form | CodingLab </title>--->
    <link rel="stylesheet" href="register.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Login</div>
    <?php echo $result; ?>
    <div class="content">
      <form action="" method="post" autocomplete="off">
        <div class="user-details">
         
          <div class="input-box">
            <span class="details">Username</span>
            <input type="text" name="username" placeholder="Enter your username *">
          </div>
 
          <div class="input-box">
            <span class="details">Password</span>
            <input type="password" name="password" placeholder="Enter your password *" >
          </div>
          
        </div>

        <div class="button">
          <input type="submit" name="submit" value="Login">
        </div>
          
      </form>
      <div style=" margin-left: 200px;">New User : -
      <a href="register.php">Register</a></div>
      
    </div>
  </div>

</body>
</html>
